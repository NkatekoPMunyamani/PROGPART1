/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package progpart1.progpart1;  
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
/**
 *
 * @author dell
 */
public class Message {
    // Shared across the whole program run
    private static final List<Message> sentMessages = new ArrayList<>();
    private static final Random RANDOM = new Random();
    public static String storagePath = "messages.json";
 
    //declarations
    String messageID;
    int messageNumber;
    String recipient;
    String messageText;
    String messageHash;
 
    // Normal use: the ID is randomly generated
    public Message(int messageNumber, String recipient, String messageText) {
        this(generateMessageID(), messageNumber, recipient, messageText);
    }
 
    // Used by the unit tests so the ID is known in advance
    public Message(String messageID, int messageNumber, String recipient, String messageText) {
        this.messageID = messageID;
        this.messageNumber = messageNumber;
        this.recipient = recipient;
        this.messageText = messageText;
        this.messageHash = createMessageHash();
    }
 
    // Randomly generated ten-digit number (leading zeros allowed)
    private static String generateMessageID() {
        long number = RANDOM.nextLong(10_000_000_000L);
        return String.format("%010d", number);
    }
 
    // Ensures the message ID is not more than ten characters
    public boolean checkMessageID() {
        return messageID != null && messageID.length() <= 10;
    }
 
    public String messageIDGenerated() {
        return "Message ID generated: " + messageID;
    }
 
    // Message must not exceed 250 characters
    public String checkMessageLength() {
        int length = messageText.length();
    
        if (length <= 250) {
            return "Message ready to send.";
        }
        else{
        return "Message exceeds 250 characters by " + (length - 250) + ", please reduce the size.";
    }
    }
 
    // Starts with "+" and an international code, then at most ten more digits
    public String checkRecipientCell() {
        if (recipient != null && recipient.matches("^\\+[0-9]{1,3}[0-9]{1,10}$")) {
            return "Cell phone number successfully captured.";
        }
        else {
        return "Cell phone number is incorrectly formatted or does not contain an international code."
                + " Please correct the number and try again.";
    }
    }
 
    // First two digits of ID : message number : FIRSTWORDLASTWORD (caps)
    public String createMessageHash() {
        String[] words = messageText.trim().split("\\s+");
        String first = clean(words[0]);
        String last = clean(words[words.length - 1]);
        return (messageID.substring(0, 2) + ":" + messageNumber + ":" + first + last).toUpperCase();
    }
 
    // Removes punctuation such as "?" or "," from a word
    private String clean(String word) {
        return word.replaceAll("[^A-Za-z0-9]", "");
    }
 
    // choice: 1 = send, 2 = disregard, 3 = store
    public String SentMessage(int choice) {
        switch (choice) {
            case 1 -> {
                sentMessages.add(this);
                return "Message successfully sent.";
            }
            case 2 -> {
                return "Press 0 to delete the message.";
            }
            case 3 -> {
                if (storeMessage()) {
                    return "Message successfully stored.";
                }
                return "Message could not be stored.";
            }
            default -> {
                return "Invalid option.";
            }
        }
    }
 
    // Returns every message sent while the program is running
    public static String printMessages() {
        if (sentMessages.isEmpty()) {
            return "No messages have been sent yet.";
        }
        StringBuilder sb = new StringBuilder();
        for (Message m : sentMessages) {
            sb.append(m.getDetails()).append("\n");
        }
        return sb.toString();
    }
 
    public static int returnTotalMessages() {
        return sentMessages.size();
    }
 
    // Saves this message to a JSON file (adds to any messages already in it)
    public boolean storeMessage() {
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        List<Message> stored = new ArrayList<>();
        Path path = Paths.get(storagePath);
        try {
            if (Files.exists(path)) {
                List<Message> existing = gson.fromJson(Files.readString(path),
                        new TypeToken<List<Message>>() { }.getType());
                if (existing != null) {
                    stored.addAll(existing);
                }
            }
            stored.add(this);
            Files.writeString(path, gson.toJson(stored));
            return true;
        } catch (IOException | RuntimeException e) {
            return false;
        }
    }
 
    // Order required by the brief: ID, Hash, Recipient, Message
    public String getDetails() {
        return "Message ID: " + messageID
                + "Message Hash: " + messageHash
                + "Recipient: " + recipient
                + "Message: " + messageText;
    }
 
    public static void clearSentMessages() {
        sentMessages.clear();
    }

    public String getMessageID() { return messageID; }
    public String getMessageHash() { return messageHash; }
    public String getRecipient() { return recipient; }
    public String getMessageText() { return messageText; }
    public int getMessageNumber() { return messageNumber; }
    }
