/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package progpart1.progpart1;
import java.util.Scanner;
/**
 *
 * @author dell
 */

public class QuickChat {

    // Called from Progpart1 once the user has logged in successfully
    public static void start(Scanner in) {
        System.out.println("Welcome to QuickChat.");
        int maxMessages = readInt(in, "How many messages do you wish to enter? ");
        int entered = 0;
        int choice = 0;

        // Runs until the user chooses 3 (Quit)
        while (choice != 3) {
            System.out.println("1.Send Messages");
            System.out.println("2.Show recently sent messages");
            System.out.println("3.Quit");
            choice = readInt(in, "Choose an option: ");

            switch (choice) {
                case 1 -> {
                    if (entered >= maxMessages) {
                        System.out.println("You have already entered the " + maxMessages + " message(s) you set.");
                    } else if (sendOneMessage(in)) {
                        entered++;
                    }
                }
                case 2 -> System.out.println("Coming Soon.");
                case 3 -> {
                }
                default -> System.out.println("Please choose 1, 2 or 3.");
            }
        }

        System.out.println("Total messages sent: " + Message.returnTotalMessages());
        System.out.println(Message.printMessages());
    }

    // Returns true if the message was sent or stored (counts toward the limit)
    private static boolean sendOneMessage(Scanner in) {
        Message msg = null;
        boolean cellOk = false;
        boolean lengthOk = false;

        // Keep asking until the recipient AND the message are both valid
        while (!cellOk || !lengthOk) {
            System.out.print("Recipient (e.g. +27718693002): ");
            String recipient = in.nextLine();
            System.out.print("Message (max 250 characters): ");
            String text = in.nextLine();

            msg = new Message(Message.returnTotalMessages(), recipient, text);
            String cellResult = msg.checkRecipientCell();
            String lengthResult = msg.checkMessageLength();

            cellOk = cellResult.equals("Cell phone number successfully captured.");
            lengthOk = lengthResult.equals("Message ready to send.");

            if (!cellOk) {
                System.out.println(cellResult);
            }
            if (!lengthOk) {
                System.out.println("Please enter a message of less than 250 characters.");
                System.out.println(lengthResult);
            }
        }

        System.out.println("Cell phone number successfully captured.");
        System.out.println("Message sent");
        System.out.println(msg.messageIDGenerated());

        int option = 0;
        while (option < 1 || option > 3) {
            System.out.println("1.Send Message");
            System.out.println("2.Disregard Message");
            System.out.println("3.Store Message to send later");
            option = readInt(in, "Choose an option: ");
        }

        String result = msg.SentMessage(option);
        System.out.println(result);

        if (option == 1) {
            System.out.println("\n" + msg.getDetails());
            return true;
        }
        if (option == 2) {
            System.out.print("> ");
            if (in.nextLine().trim().equals("0")) {
                System.out.println("Message deleted.");
            }
            return false;
        }
        return result.equals("Message successfully stored.");
    }

    // Keeps asking until the user types a whole number
    private static int readInt(Scanner in, String prompt) {
        int number = 0;
        boolean valid = false;

        while (!valid) {
            System.out.print(prompt);
            try {
                number = Integer.parseInt(in.nextLine().trim());
                valid = true;
            } catch (NumberFormatException e) {
                System.out.println("Please enter a number.");
            }
        }
        return number;
    }
}
