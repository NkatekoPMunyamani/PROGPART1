/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import java.nio.file.Files;
import java.nio.file.Path;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import progpart1.progpart1.Message;

/**
 *
 * @author dell
 */
public class MessageTest {

    // Test data from the brief
    private static final String RECIPIENT_1 = "+27718693002";
    private static final String TEXT_1 = "Hi Mike, can you join us for dinner tonight?";
    private static final String RECIPIENT_2 = "08575975889";
    private static final String TEXT_2 = "Hi Keegan, did you receive the payment?";

    public MessageTest() {
    }

    // BEFORE ALL: runs ONCE, before the first test starts
    @BeforeAll
    public static void setUpClass() {
    }

    // AFTER ALL: runs ONCE, after the last test finishes
    @AfterAll
    public static void tearDownClass() {
    }

    // BEFORE EACH: runs before EVERY test (start clean)
    @BeforeEach
    public void setUp() throws Exception {
        Message.clearSentMessages();
        Message.storagePath = "test_messages.json";
        Files.deleteIfExists(Path.of(Message.storagePath));
    }

    // AFTER EACH: runs after EVERY test (clean up)
    @AfterEach
    public void tearDown() throws Exception {
        Message.clearSentMessages();
        Files.deleteIfExists(Path.of(Message.storagePath));
    }


    // Message of 250 characters or less: success message
    @Test
    public void messageLengthSuccess() {
        Message m = new Message("0012345678", 0, RECIPIENT_1, TEXT_1);
        assertEquals("Message ready to send.", m.checkMessageLength());
    }

    // Message of 260 characters: failure message (10 over the limit)
    @Test
    public void messageLengthFailure() {
        Message m = new Message("0012345678", 0, RECIPIENT_1, "a".repeat(260));
        assertEquals("Message exceeds 250 characters by 10, please reduce the size.",
                m.checkMessageLength());
    }

    // Recipient +27718693002 has an international code: success
    @Test
    public void recipientNumberSuccess() {
        Message m = new Message("0012345678", 0, RECIPIENT_1, TEXT_1);
        assertEquals("Cell phone number successfully captured.", m.checkRecipientCell());
    }

    // Recipient 08575975889 has no international code: failure
    @Test
    public void recipientNumberFailure() {
        Message m = new Message("1234567890", 1, RECIPIENT_2, TEXT_2);
        assertEquals("Cell phone number is incorrectly formatted or does not contain an international code."
                + " Please correct the number and try again.", m.checkRecipientCell());
    }

    // Test Case 1: hash must be 00:0:HITONIGHT
    @Test
    public void messageHashTestCase1() {
        Message m = new Message("0012345678", 0, RECIPIENT_1, TEXT_1);
        assertEquals("00:0:HITONIGHT", m.createMessageHash());
    }

    // Checks the hashes of both test messages in a loop
    @Test
    public void messageHashLoop() {
        String[] ids = {"0012345678", "1234567890"};
        String[] texts = {TEXT_1, TEXT_2};
        String[] expected = {"00:0:HITONIGHT", "12:1:HIPAYMENT"};

        for (int i = 0; i < ids.length; i++) {
            Message m = new Message(ids[i], i, RECIPIENT_1, texts[i]);
            assertEquals(expected[i], m.createMessageHash());
        }
    }

    // Message ID is created, is 10 characters, and prints correctly
    @Test
    public void messageIDIsCreated() {
    
       Message m = new Message(0, RECIPIENT_1, TEXT_1);
        assertEquals(10, m.getMessageID().length());
        assertTrue(m.checkMessageID());
        assertEquals("Message ID generated: " + m.getMessageID(), m.messageIDGenerated());
    }

    // User selected 'Send Message'
    @Test
    public void messageSentOption1() {
        Message m = new Message(0, RECIPIENT_1, TEXT_1);
        assertEquals("Message successfully sent.", m.SentMessage(1));
        assertEquals(1, Message.returnTotalMessages());
    }

    // User selected 'Disregard Message'
    @Test
    public void messageSentOption2() {
        Message m = new Message(1, RECIPIENT_2, TEXT_2);
        assertEquals("Press 0 to delete the message.", m.SentMessage(2));
        assertEquals(0, Message.returnTotalMessages());
    }

    // User selected 'Store Message': saved to the JSON file
    @Test
    public void messageSentOption3() throws Exception {
        Message m = new Message(0, RECIPIENT_1, TEXT_1);
        assertEquals("Message successfully stored.", m.SentMessage(3));
        assertTrue(Files.exists(Path.of(Message.storagePath)));
        assertTrue(Files.readString(Path.of(Message.storagePath)).contains((CharSequence) m.getMessageID()));
    }

    // Total messages after two messages are sent
    @Test
    public void totalMessagesAfterTwoSends() {
        new Message(0, RECIPIENT_1, TEXT_1).SentMessage(1);
        new Message(1, RECIPIENT_1, TEXT_2).SentMessage(1);
        assertEquals(2, Message.returnTotalMessages());
    }
}