/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package progpart1.progpart1;

/**
 *
 * @author dell
 */
public class Login {
    //Declarations
    String registeredUsername;
    String registeredPassword;
    String registeredCellphoneNumber;
    String firstName;
    String lastName;
    boolean lastLoginSuccessful;

    // 1. Check if the username contain an underscore and must not be more than five characters long.
    public boolean checkUserName(String username) {
        
        return username.contains("_") && username.length() <= 5;
    }

    // 2. Check if password has at least eight characters, a capital letter, a number, and a special character.
    public boolean checkPasswordComplexity(String password) {
        if (password.length() < 8) 
        {
            return false;
        }
        boolean hasCapitalLetter = false; 
        boolean hasNumber = false; 
        boolean hasSpecialCharacter = false;

        // the password into a list of characters the for loop can step through.
        for (int i = 0; i < password.length(); i++){
        char character = password.charAt(i);
        
            if (Character.isUpperCase(character))
            {
                hasCapitalLetter = true;
            }
            
            if (Character.isDigit(character)) 
            {
                hasNumber = true;
            }
            if (!Character.isLetterOrDigit(character)) 
            {
                hasSpecialCharacter = true;
            }
        }
        return hasCapitalLetter && hasNumber && hasSpecialCharacter;
    }

    // 3. Check if cell phone number contains the international country code (+27).
    //w3schools regex
    public boolean checkCellPhoneNumber(String cellPhone) {
     
        return cellPhone.matches("^\\+27[0-9]{9}$");
    }
    
    // Register the user 
    public String registerUser(String username, String password, String cellPhone,
                                String firstName, String lastName) {
        String text = "Username is not correctly formatted, please ensure that your username contains an underscore "
                + "and is no more than five characters in length.";
        
        if (!checkUserName(username)) 
        {
            return text;   
        } 
        else if (!checkPasswordComplexity(password)) 
        {
            return "Password is not correctly formatted, please ensure that the password contains at least eight characters,"
                    + " a capital letter, a number, and a special character.";
        } 
        else if (!checkCellPhoneNumber(cellPhone)) 
        {
            return "Cell phone number is not correctly formatted or does not contain international code,"
                    + " please enter the correct number and try again";
        } 
        else 
        {
            registeredUsername = username;
            registeredPassword = password;
            registeredCellphoneNumber = cellPhone;
            this.firstName = firstName;
            this.lastName = lastName;
            return "The conditions have been met, and the user has been registered successfully.";
        }
    }

    public boolean loginUser(String username, String password) {
   
       if (username == null || password == null)
       {
           lastLoginSuccessful = false;
           return false;
       }
       if (username.equals(registeredUsername) && password.equals(registeredPassword)){
           lastLoginSuccessful = true;
           return true;
       }
       else {
           lastLoginSuccessful = false;
           return false;
       }
       }

    public String returnLoginStatus() {
         
        if (lastLoginSuccessful) {
            return "Welcome " + firstName + " " + lastName +", "+ "it is great to see you:)!!!";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }
}
    

