/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package progpart1.progpart1;

/**
 * @author dell
 */
import java.util.Scanner;
public class Progpart1 {

    public static void main(String[] args) {
        System.out.println("PROG PART 1");
        Scanner input = new Scanner(System.in);
            //Declarations
            String firstName;
            String lastName;
            String username;
            String password;
            String cellPhone;
            String loginUsername;
            String loginPassword;
            String registrationMessage;
            // Create a Login object
            Login user = new Login();
            
            // Ask for first name
            System.out.print("Enter your first name: ");
            firstName = input.nextLine();
            // Ask for last name
            System.out.print("Enter your last name: ");
            lastName = input.nextLine();
            // Ask for username
            System.out.print("Enter your username: ");
            username = input.nextLine();
            // While loop for when username is not correctly formatted
            while (!user.checkUserName(username)) {
                
                System.out.println(
                        "Username is not correctly formatted, please ensure that "
                                + "your username contains an underscore and is no more than "
                                + "five characters in length."
                );
                
                System.out.print("Enter your username: ");
                username = input.nextLine();
            }
            
            // Ask for password
            System.out.print("Enter your password: ");
            password = input.nextLine();
            
            //While loop for when password is not correctly formatted
            while (!user.checkPasswordComplexity(password)) {
                
                System.out.println(
                        "Password is not correctly formatted, please ensure that "
                                + "the password contains at least eight characters, a capital "
                                + "letter, a number, and a special character."
                );
                
                System.out.print("Enter your password: ");
                password = input.nextLine();
            }
            
            // Ask for cellphone number
            System.out.print("Enter your cellphone number: ");
            cellPhone = input.nextLine();
            
            //While loop for when cellphone number is not correctly formatted
            while (!user.checkCellPhoneNumber(cellPhone)) {
                
                System.out.println(
                        "Cell phone number is not correctly formatted and does not "
                                + "contain international code, please enter the correct number "
                                + "and try again."
                );
                
                System.out.print("Enter your cellphone number: ");
                cellPhone = input.nextLine();
            }
            
            // Register the user
            registrationMessage = user.registerUser(username, password, cellPhone, firstName, lastName );
            
            System.out.println(registrationMessage);
            
            // Login section
            if (registrationMessage.equals(
                    "The conditions have been met, and the user has been registered successfully."
            )) {
                
                System.out.print("Enter your username to login: ");
                loginUsername = input.nextLine();
                
                System.out.print("Enter your password to login: ");
                loginPassword = input.nextLine();
                
                // Check login details
                user.loginUser(loginUsername, loginPassword);
                
                // Display login status
                System.out.println(user.returnLoginStatus());
            }
        }
    }


