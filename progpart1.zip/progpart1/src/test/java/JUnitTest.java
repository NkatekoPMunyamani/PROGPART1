/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import progpart1.progpart1.Login;

/**
 *
 * @author dell
 */
public class JUnitTest {
    
    Login login;
    
    public JUnitTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
        login = new Login();
    }
    
    @AfterEach
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
   
    // Test username - correctly formatted
    @Test
    public void testCheckUserNameCorrect() {
        assertTrue(login.checkUserName("kyl_"));
    }

    // Test username - incorrectly formatted
    @Test
    public void testCheckUserNameIncorrect() {
        assertFalse(login.checkUserName("kyle"));
    }

    // Test username - more than five characters
    @Test
    public void testCheckUserNameTooLong() {
        assertFalse(login.checkUserName("kyle_1"));
    }

    // Test password - correctly formatted
    @Test
    public void testCheckPasswordCorrect() {
        assertTrue(login.checkPasswordComplexity("Password1!"));
    }

    // Test password - less than eight characters
    @Test
    public void testCheckPasswordTooShort() {
        assertFalse(login.checkPasswordComplexity("Pass1!"));
    }

    // Test password - no capital letter
    @Test
    public void testCheckPasswordNoCapital() {
        assertFalse(login.checkPasswordComplexity("password1!"));
    }

    // Test password - no number
    @Test
    public void testCheckPasswordNoNumber() {
        assertFalse(login.checkPasswordComplexity("Password!"));
    }

    // Test password - no special character
    @Test
    public void testCheckPasswordNoSpecialCharacter() {
        assertFalse(login.checkPasswordComplexity("Password1"));
    }

    // Test cellphone number - correctly formatted
    @Test
    public void testCheckCellPhoneNumberCorrect() {
        assertTrue(login.checkCellPhoneNumber("+27821234567"));
    }

    // Test cellphone number - incorrectly formatted
    @Test
    public void testCheckCellPhoneNumberIncorrect() {
        assertFalse(login.checkCellPhoneNumber("0821234567"));
    }

    // Test cellphone number - incorrect length
    @Test
    public void testCheckCellPhoneNumberIncorrectLength() {
        assertFalse(login.checkCellPhoneNumber("+2782123456"));
    }

    // Test registration - successful
    @Test
    public void testRegisterUserSuccessful() {
        
        String result = login.registerUser(
                "kyl_",
                "Password1!",
                "+27821234567",
                "John",
                "Doe"
        );

        assertEquals(
                "The conditions have been met, and the user has been registered successfully.",
                result
        );
    }

    // Test registration - incorrect username
    @Test
    public void testRegisterUserIncorrectUsername() {
        
        String result = login.registerUser(
                "kyle",
                "Password1!",
                "+27821234567",
                "John",
                "Doe"
        );

        assertEquals(
                "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.",
                result
        );
    }

    // Test registration - incorrect password
    @Test
    public void testRegisterUserIncorrectPassword() {
        
        String result = login.registerUser(
                "kyl_",
                "password",
                "+27821234567",
                "John",
                "Doe"
        );

        assertEquals(
                "Password is not correctly formatted, please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.",
                result
        );
    }

    // Test registration - incorrect cellphone number
    @Test
    public void testRegisterUserIncorrectCellPhone() {
        
        String result = login.registerUser(
                "kyl_",
                "Password1!",
                "0821234567",
                "John",
                "Doe"
        );

        assertEquals(
                "Cell phone number is not correctly formatted or does not contain international code, please enter the correct number and try again",
                result
        );
    }

    // Test login - successful
    @Test
    public void testLoginUserSuccessful() {
        
        login.registerUser(
                "kyl_",
                "Password1!",
                "+27821234567",
                "John",
                "Doe"
        );

        assertTrue(login.loginUser("kyl_", "Password1!"));
    }

    // Test login - incorrect username
    @Test
    public void testLoginUserIncorrectUsername() {
        
        login.registerUser(
                "kyl_",
                "Password1!",
                "+27821234567",
                "John",
                "Doe"
        );

        assertFalse(login.loginUser("wrong_", "Password1!"));
    }

    // Test login - incorrect password
    @Test
    public void testLoginUserIncorrectPassword() {
        
        login.registerUser(
                "kyl_",
                "Password1!",
                "+27821234567",
                "John",
                "Doe"
        );

        assertFalse(login.loginUser("kyl_", "Wrong1!"));
    }

    // Test login status - successful login
    @Test
    public void testReturnLoginStatusSuccessful() {
        
        login.registerUser(
                "kyl_",
                "Password1!",
                "+27821234567",
                "John",
                "Doe"
        );

        login.loginUser("kyl_", "Password1!");

        assertEquals(
                "Welcome John Doe, it is great to see you:)!!!",
                login.returnLoginStatus()
        );
    }

    // Test login status - unsuccessful login
    @Test
    public void testReturnLoginStatusUnsuccessful() {
        
        login.registerUser(
                "kyl_",
                "Password1!",
                "+27821234567",
                "John",
                "Doe"
        );

        login.loginUser("wrong_", "Wrong1!");

        assertEquals(
                "Username or password incorrect, please try again.",
                login.returnLoginStatus()
        );
    }
}

