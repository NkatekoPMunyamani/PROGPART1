/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

package progpart1.progpart1;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author dell
 */
public class StoredMessageTest {

    private StoredMessage storedMessage;
    private Path temporaryFile;
    private String originalStoragePath;
    private Message firstMessage;
    private Message secondMessage;

    public StoredMessageTest() {
    }

    @BeforeAll
    public static void setUpClass() {
    }

    @AfterAll
    public static void tearDownClass() {
    }

    @BeforeEach
    public void setUp() throws IOException {

        originalStoragePath = Message.storagePath;

        temporaryFile = Files.createTempFile(
                "test-messages", ".json");

        Message.storagePath = temporaryFile.toString();

        firstMessage = new Message(
                "1234567890",
                1,
                "0821234567",
                "Hello this is my first test message."
        );

        secondMessage = new Message(
                "0987654321",
                2,
                "0831234567",
                "This is my second and longer test message."
        );

        List<Message> messages = new ArrayList<>();

        messages.add(firstMessage);
        messages.add(secondMessage);

        Gson gson = new GsonBuilder()
                .setPrettyPrinting()
                .create();

        Files.writeString(
                temporaryFile,
                gson.toJson(messages)
        );

        storedMessage = new StoredMessage();
    }

    @AfterEach
    public void tearDown() throws IOException {

        Message.storagePath = originalStoragePath;

        if (temporaryFile != null) {
            Files.deleteIfExists(temporaryFile);
        }
    }

    @Test
    public void testLoadStoredMessages() {

        storedMessage.loadStoredMessages();

        assertEquals(2, storedMessage.messageCount);

        assertEquals(
                "1234567890",
                storedMessage.messageIDs[0]
        );

        assertEquals(
                "0821234567",
                storedMessage.messageRecipients[0]
        );
    }

    @Test
    public void testDisplayStoredSendersAndRecipients() {

        String output = captureOutput(() ->
                storedMessage.displayStoredSendersAndRecipients()
        );

        assertTrue(output.contains("0821234567"));
        assertTrue(output.contains("0831234567"));

        assertTrue(output.contains(
                "Hello this is my first test message."
        ));
    }

    @Test
    public void testGetLongestStoredMessage() {

        String output = captureOutput(() ->
                storedMessage.getLongestStoredMessage()
        );

        assertTrue(output.contains("Longest stored message:"));

        assertTrue(output.contains(
                "This is my second and longer test message."
        ));
    }

    @Test
    public void testSearchByMessageID() {

        Scanner input = new Scanner("1234567890\n");

        String output = captureOutput(() ->
                storedMessage.searchByMessageID(input)
        );

        assertTrue(output.contains("0821234567"));

        assertTrue(output.contains(
                "Hello this is my first test message."
        ));
    }

    @Test
    public void testSearchByRecipient() {

        Scanner input = new Scanner("0831234567\n");

        String output = captureOutput(() ->
                storedMessage.searchByRecipient(input)
        );

        assertTrue(output.contains("0987654321"));

        assertTrue(output.contains(
                "This is my second and longer test message."
        ));
    }

    @Test
    public void testDeleteByMessageHash() {

        String hash = firstMessage.getMessageHash();

        Scanner input = new Scanner(hash + "\n");

        String output = captureOutput(() ->
                storedMessage.deleteByMessageHash(input)
        );

        assertTrue(output.contains(
                "Message successfully deleted."
        ));

        storedMessage.loadStoredMessages();

        assertEquals(1, storedMessage.messageCount);

        assertEquals(
                "0987654321",
                storedMessage.messageIDs[0]
        );
    }

    @Test
    public void testGenerateReport() {

        String output = captureOutput(() ->
                storedMessage.generateReport()
        );

        assertTrue(output.contains("MESSAGE REPORT"));
        assertTrue(output.contains("1234567890"));
        assertTrue(output.contains("0987654321"));

        assertTrue(output.contains(
                "Total stored messages: 2"
        ));
    }

    private String captureOutput(Runnable action) {

        ByteArrayOutputStream output =
                new ByteArrayOutputStream();

        PrintStream originalOutput = System.out;

        System.setOut(new PrintStream(output));

        try {

            action.run();

        } finally {

            System.setOut(originalOutput);
        }

        return output.toString();
    }
}