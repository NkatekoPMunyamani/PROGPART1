/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package progpart1.progpart1;

/**
 *
 * @author dell
 */
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class StoredMessage {


    // Array declarations
    String[] sentMessages = new String[100];
    String[] disregardedMessages = new String[100];
    String[] storedMessages = new String[100];
    String[] messageHashes = new String[100];
    String[] messageIDs = new String[100];
    String[] messageRecipients = new String[100];

    Message[] messageObjects = new Message[100];

    int messageCount = 0;

    // File path
    Path path = Paths.get(Message.storagePath);

    // Read messages from JSON file and populate arrays
    public void loadStoredMessages() {
        // Load sent messages into the sentMessages array
        List<Message> sent = Message.getSentMessages();

        for (int i = 0; i < sent.size() && i < 100; i++) {
           sentMessages[i] = sent.get(i).getMessageText();
        }

        // Load disregarded messages into the disregardedMessages array
        List<Message> disregarded = Message.getDisregardedMessages();

        for (int i = 0; i < disregarded.size() && i < 100; i++) {
           disregardedMessages[i] = disregarded.get(i).getMessageText();
        }

        Gson gson = new Gson();

        try {

            if (Files.exists(path)) {

                String json = Files.readString(path);

                List<Message> messages = gson.fromJson(
                        json,
                        new TypeToken<List<Message>>() {
                        }.getType()
                );

                messageCount = 0;

                if (messages != null) {

                    for (Message message : messages) {

                        if (messageCount < 100) {

                            messageObjects[messageCount] = message;

                            messageIDs[messageCount] =
                                    message.getMessageID();

                            messageHashes[messageCount] =
                                    message.getMessageHash();

                            messageRecipients[messageCount] =
                                    message.getRecipient();

                            storedMessages[messageCount] =
                                    message.getMessageText();

                            messageCount++;
                        }
                    }
                }
            }

        } catch (IOException | RuntimeException e) {

            System.out.println("Error reading stored messages.");

        }
    }

    // Display stored senders and recipients
    public void displayStoredSendersAndRecipients() {

        loadStoredMessages();

        if (messageCount == 0) {

            System.out.println("No stored messages available.");

        } else {

            for (int i = 0; i < messageCount; i++) {

                System.out.println("Recipient: "
                        + messageRecipients[i]);

                System.out.println("Message ID: "
                        + messageIDs[i]);

                System.out.println("Message: "
                        + storedMessages[i]);

            }
        }
    }

    // Display the longest stored message
    public void getLongestStoredMessage() {

        loadStoredMessages();

        if (messageCount == 0) {

            System.out.println("No stored messages available.");

        } else {

            int longestMessage = 0;

            for (int i = 1; i < messageCount; i++) {

                if (storedMessages[i].length()
                        > storedMessages[longestMessage].length()) {

                    longestMessage = i;
                }
            }

            System.out.println("Longest stored message:");

            System.out.println(storedMessages[longestMessage]);
        }
    }

    // Search for a message using its ID
    public void searchByMessageID(Scanner input) {

        loadStoredMessages();

        System.out.print("Enter message ID: ");

        String searchID = input.nextLine();

        boolean found = false;

        for (int i = 0; i < messageCount; i++) {

            if (messageIDs[i].equals(searchID)) {

                System.out.println("Recipient: "
                        + messageRecipients[i]);

                System.out.println("Message: "
                        + storedMessages[i]);

                found = true;
            }
        }

        if (!found) {

            System.out.println("Message not found.");
        }
    }

    // Search for messages using recipient
    public void searchByRecipient(Scanner input) {

        loadStoredMessages();

        System.out.print("Enter recipient number: ");

        String recipient = input.nextLine();

        boolean found = false;

        for (int i = 0; i < messageCount; i++) {

            if (messageRecipients[i].equals(recipient)) {

                System.out.println("Message ID: "
                        + messageIDs[i]);

                System.out.println("Message: "
                        + storedMessages[i]);

                found = true;
            }
        }

        if (!found) {

            System.out.println("No messages found for this recipient.");
        }
    }

    // Delete a message using its hash
    public void deleteByMessageHash(Scanner input) {

        loadStoredMessages();

        System.out.print("Enter message hash: ");

        String searchHash = input.nextLine();

        int foundIndex = -1;

        for (int i = 0; i < messageCount; i++) {

            if (messageHashes[i].equals(searchHash)) {

                foundIndex = i;
                break;
            }
        }

        if (foundIndex == -1) {

            System.out.println("Message not found.");

        } else {

            List<Message> messages = new ArrayList<>();

            for (int i = 0; i < messageCount; i++) {

                if (i != foundIndex) {

                    messages.add(messageObjects[i]);
                }
            }

            Gson gson = new GsonBuilder()
                    .setPrettyPrinting()
                    .create();

            try {

                Files.writeString(path, gson.toJson(messages));

                System.out.println("Message successfully deleted.");

                loadStoredMessages();

            } catch (IOException e) {

                System.out.println("Unable to delete message.");
            }
        }
    }

    // Generate message report
    public void generateReport() {

        loadStoredMessages();

        if (messageCount == 0) {

            System.out.println("No stored messages available.");

        } else {

            System.out.println("MESSAGE REPORT");

            for (int i = 0; i < messageCount; i++) {

                System.out.println("Message ID: "
                        + messageIDs[i]);

                System.out.println("Message Hash: "
                        + messageHashes[i]);

                System.out.println("Recipient: "
                        + messageRecipients[i]);

                System.out.println("Message: "
                        + storedMessages[i]);

                System.out.println("--------------------------------");
            }

            System.out.println("Total stored messages: "
                    + messageCount);
        }
    }

    // Stored messages menu
    public void storedMessagesMenu(Scanner input) {

        int option = 0;

        while (option != 7) {

            System.out.println("\nSTORED MESSAGES MENU");

            System.out.println("1. Display stored messages");
            System.out.println("2. Display longest stored message");
            System.out.println("3. Search by message ID");
            System.out.println("4. Search by recipient");
            System.out.println("5. Delete message by hash");
            System.out.println("6. Generate report");
            System.out.println("7. Return to main menu");

            System.out.print("Choose an option: ");

            try {

                option = Integer.parseInt(input.nextLine());

                switch (option) {

                    case 1 -> displayStoredSendersAndRecipients();

                    case 2 -> getLongestStoredMessage();

                    case 3 -> searchByMessageID(input);

                    case 4 -> searchByRecipient(input); 

                    case 5 -> deleteByMessageHash(input);

                    case 6 -> generateReport();

                    case 7 -> System.out.println("Returning to main menu.");

                    default -> System.out.println("Invalid option.");
                }

            } catch (NumberFormatException e) {

                System.out.println("Please enter a valid number.");
            }
        }
    }
}
